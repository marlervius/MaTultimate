"""MaTultimate API."""
from .routes import router
