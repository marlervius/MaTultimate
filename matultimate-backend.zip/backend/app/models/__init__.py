"""MaTultimate Models."""
from .schemas import *
